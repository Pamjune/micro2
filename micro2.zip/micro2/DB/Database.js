const mongoose=require('mongoose');

 mongoose.connect("mongodb://localhost:27017/bancoservice");

 mongoose.connection.once("open",()=>console.log("banco conectado no mongoose"));


 module.exports = mongoose;