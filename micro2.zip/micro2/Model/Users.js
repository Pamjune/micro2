const mongoose = require('mongoose');


var SchemaUsers = mongoose.Schema({
   name : String,
   password : String,
   email : {type: String},
   active: Number,
   status: String,
   token : String,
   dataCreated : Date

});

module.exports = mongoose.model('users', SchemaUsers);