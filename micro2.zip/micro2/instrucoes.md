
## Instruções

mkdir microservices
cd microservices

npm init -y

## O comando acima cria o package 

 Local onde insiro as dependências (pacotes)
 pacotes do node

## dependências 
  Java 


  code .
  spript _ angular, react, nodejs

  atom ##

  #############################

DB _ Folder


MOdel_ A CLASSE EM JS



 DICA

 QUANDO EU FALAR JS /  TypeScript (ANgular)

  nome : String _ nodejs ou React ou Vue 



  nome :string _ node nestjs (microservices) _ typesceript, Angular


############### 

instalações 1 etapa

 _ Raiz (instalação e Execução)
 ls -la

 #################

instalação (package.json)

instalar o middleware express (node)
instalar o mongodb
instalar o mongoose
--> node assyncrona -- mongodb

######################################

mongodb

##################################
mongo _ versão 4.0


windows _ mongo _ 3.2  _ 3.6

cd \
cd mongodb
cd bin
mongod
mongo


########################################
 mongo _ ele entra _ 4.0 acima

 #######################################
 
 criar database use nomebanco

 ## crio e entro no banco

 use bancoservice;

## criar uma collection (https://mongoosejs.com/docs/guide.html)

 db.createCollection("users");
 
show collections;

##> database Cuidar bancoservice

##> Model cuidar Collection



################## Basico instalação de pacotes
 primeiro globsl -g
 depois local

 npm i -g mongodb mongoose express body-parser md5 uuidv4 __ instalção na máquina
 npm i  mongodb mongoose express body-parser md5 uuidv4 _ package



npm i cors

Básico _ 

md5
uuid
moment

npm i md5 uuid

npm i date-and-time --save
















