const express = require('express');
const bodyParser = require('body-parser');
const mongooses = require('mongoose');
const cors = require('cors');
const UsersModel = require('./Model/Users');
const md5 = require('md5');
const { v4: uuidv4 } = require('uuid');
const datas = require('date-and-time');

require('./DB/Database');  //abringo o banco ed dados
let chave = "profedsonbelem@gmail.com;www.edsonbelemtreinamento.com.br;1+1=1;ZZZ.br.TS.gb";

function criptografia(password){
   let senha1 = md5(password + chave);
   let senha2 = md5('minha chave' + chave);
   let senha3 = md5(new Date() + chave);  
   let senha4 =  md5(uuidv4() + chave);
   return senha1 + senha2  + senha3 + senha4;
}

app = express();


app.use(cors());
app.use(bodyParser.json());


 app.post("/api/users", async (req,res)=>{
  
    let users = new UsersModel(req.body); //recebe tudo que você disparar
     let data = new Date();
      data.setHours( data.getHours() -3 );
     users.password = criptografia(users.passord);
     users.active = 1;
     users.status = 'created'; 
     users.dataCreated= datas.format(data,'YYYY-MM-DD HH:mm:ss');
      await UsersModel.create(users).then(resp=>{
          return res.status(200).json(resp)
      }
      ).catch(err=>{
         return res.status(500).json({'error':'error internal server, Users not saved'})
      })

    
 });

 app.get("/api/users", async (req,res)=>{
   
     await UsersModel.find().then(resp=>{
         return res.status(200).json(resp)
     }
     ).catch(err=>{
        return res.status(500).json({'error':'error internal server'})
     })

   
});

app.post("/api/login", async (req,res)=>{
  try{
   let users = new UsersModel(req.body); //recebe tudo que você disparar
  
     await UsersModel.findOne({email: users.email}).then(resp=>{
            if (!resp){
               throw new Error('not found');
            }
      return res.status(200).json(resp)
     }
     ).catch(err=>{
        return res.status(404).json({'error':'not found'})
     })
   }catch(error){
      return res.status(404).json({'error':'not found'})
   }
   
});



app.listen(3500, ()=>{
    console.log('conectado ao sistema, api funcionando Porta 3500')
});



